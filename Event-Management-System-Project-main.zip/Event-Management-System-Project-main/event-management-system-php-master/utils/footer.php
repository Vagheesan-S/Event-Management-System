<hr class = "footerline"><!--css modified horizontal line-->
<footer style="background:black;">
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                      <h3>Event Management System</h3>
                    </p>

                    <p class = "footerSubtext2">
                        Copyright @Batch 15
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                  
                </div>
                <p id="dateAndTime"></p>

            </section>
            <section>

            </section>
        </div>
    </div>
</footer>
